const Router = require('express');

// API middlewares
const { createUsAPI, viewUsAPI, updateUsAPI, deleteUsAPI} = require('../api/us.api');

// Inicializar router
const router = Router();

// Rutas post
router.post('/puntos/createPun', createUsAPI);

// Rutas get
router.get('/puntos/viewPun', viewUsAPI);

// Rutas put
router.put('/puntos/updatePun', updateUsAPI);

// Rutas delete
router.delete('/puntos/deletePun', deleteUsAPI);

module.exports = router;

// Rutas put

