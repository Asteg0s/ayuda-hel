const Us = require('../models/us.model.js');

async function createUs(options) {
  const punto = new Us(
    options.tiempo,  

  );

  try {
    userResult = await Us.createUs();
  } catch (error) {
    if (error.statusCode) throw error;
    console.log(error);
    throw {
      ok: false,
      statusCode: 500,
      data: 'Ocurrió un error al crear el usuario'
    };
  }

  return {
    message: 'Usuario creado exitosamente',
    userId: userResult.id
  };
}

async function viewUs() {
  const punto = new Us();
  let userResult;
  
  try {
    userResult = await Us.viewUs();
  } catch (error) {
    if (error.statusCode) throw error;
    console.log(error);
    throw {
      ok: false,
      statusCode: 500,
      data: 'Ocurrió un error al obtener los usuarios'
    };
  }

  return userResult;
}

async function updateUs(options) {
  const punto = new Us(
    options.tiempo, 
  );

  try {
    userResult = await Us.updateUs(options.id);
  } catch (error) {
    if (error.statusCode) throw error;
    console.log(error);
    throw {
      ok: false,
      statusCode: 500,
      data: 'Ocurrió un error al actualizar el usuario'
    };
  }

  return {
    message: 'Usuario actualizado exitosamente',
    userId: userResult.id
  };
}

async function deleteUs(options) {
  const us = new Us();

  try {
    userResult = await Us.deleteUs(options.id);
  } catch (error) {
    if (error.statusCode) throw error;
    console.log(error);
    throw {
      ok: false,
      statusCode: 500,
      data: 'Ocurrió un error al eliminar el usuario'
    };
  }

  return {
    message: 'Usuario eliminado exitosamente',
    userId: userResult.id
  };
}

module.exports = {
  createUs,
  viewUs,
  updateUs,
  deleteUs
};