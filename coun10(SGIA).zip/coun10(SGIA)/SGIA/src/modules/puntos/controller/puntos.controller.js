const Punto = require('../models/puntos.model.js');

async function createPun(options) {
  const punto = new Punto(
    options.nombre, 
    options.marca, 

  );

  try {
    userResult = await punto.createPun();
  } catch (error) {
    if (error.statusCode) throw error;
    console.log(error);
    throw {
      ok: false,
      statusCode: 500,
      data: 'Ocurrió un error al crear el usuario'
    };
  }

  return {
    message: 'Usuario creado exitosamente',
    userId: userResult.id
  };
}

async function viewPun() {
  const punto = new Punto();
  let userResult;
  
  try {
    userResult = await punto.viewPun();
  } catch (error) {
    if (error.statusCode) throw error;
    console.log(error);
    throw {
      ok: false,
      statusCode: 500,
      data: 'Ocurrió un error al obtener los usuarios'
    };
  }

  return userResult;
}

async function updatePun(options) {
  const punto = new Punto(
    options.nombre, 
    options.marca, 
  );

  try {
    userResult = await punto.updatePun(options.id);
  } catch (error) {
    if (error.statusCode) throw error;
    console.log(error);
    throw {
      ok: false,
      statusCode: 500,
      data: 'Ocurrió un error al actualizar el usuario'
    };
  }

  return {
    message: 'Usuario actualizado exitosamente',
    userId: userResult.id
  };
}

async function deletePun(options) {
  const punto = new Punto();

  try {
    userResult = await punto.deletePun(options.id);
  } catch (error) {
    if (error.statusCode) throw error;
    console.log(error);
    throw {
      ok: false,
      statusCode: 500,
      data: 'Ocurrió un error al eliminar el usuario'
    };
  }

  return {
    message: 'Usuario eliminado exitosamente',
    userId: userResult.id
  };
}

module.exports = {
  createPun,
  viewPun,
  updatePun,
  deletePun
};