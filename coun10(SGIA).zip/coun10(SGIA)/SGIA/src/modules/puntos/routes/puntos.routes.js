const Router = require('express');

// API middlewares
const { createPunAPI, viewPunAPI, updatePunAPI, deletePunAPI} = require('../api/puntos.api');

// Inicializar router
const router = Router();

// Rutas post
router.post('/puntos/createPun', createPunAPI);

// Rutas get
router.get('/puntos/viewPun', viewPunAPI);

// Rutas put
router.put('/puntos/updatePun', updatePunAPI);

// Rutas delete
router.delete('/puntos/deletePun', deletePunAPI);

module.exports = router;

// Rutas put

