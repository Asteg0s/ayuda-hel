document.getElementById('boton_jugar').addEventListener('click', function() {
    document.getElementById('menu-container').style.display = 'none'; // Ocultar el menú
    startCountdown();
});

function startCountdown() {
    document.getElementById('preparado').style.display = 'block';

    let countdown = 3;
    const preparadot = document.getElementById('preparadot');

    const interval = setInterval(function() {
        if (countdown > 0) {
            preparadot.innerHTML = countdown;
            countdown--;
        } else {
            preparadot.innerHTML = "¡YA!";
            clearInterval(interval);

            setTimeout(function() {
                preparadot.innerHTML = '';
                startGame();
            }, 1000);
        }
    }, 1000);
}

function startGame() {
    // Mostrar el contador y el botón de detener
    document.getElementById('contador').style.display = 'block';  // Mostrar el contador
    document.getElementById('boton-jugar').style.display = 'block';  // Mostrar el botón

    let contador = 0; // Empezamos el contador desde 0
    const contadorDisplay = document.getElementById('contador');
    let gameInterval = setInterval(function() {
        if (contador < 20) {
            contador += 0.01; // Incrementar en 0.01 para obtener dos decimales
            contadorDisplay.innerHTML = contador.toFixed(2); // Mostrar con 2 decimales
        } else {
            clearInterval(gameInterval);
            showResult('¡Tiempo fuera!');
        }
    }, 10); // Cambiamos el intervalo a 10 ms para mayor precisión en milisegundos

    // Lógica para el botón de detener
    document.getElementById('boton-jugar').addEventListener('click', function() {
        clearInterval(gameInterval); // Detenemos el contador
        showResult(`¡${contador.toFixed(2)}s/10s!`); // Mostrar resultado con 2 decimales
    });

    // Evento para volver al menú
    document.getElementById('boton-menu').addEventListener('click', function() {
        resetGame();
    });
}

function showResult(message) {
    // Mostrar mensaje al final del juego
    document.getElementById('mensaje').innerHTML = message;
    document.getElementById('boton-jugar').style.display = 'none'; // Ocultar el botón de detener
    document.getElementById('contador').style.display = 'none'; // Ocultar el contador
    document.getElementById('boton-menu').style.display = 'block'; // Mostrar el botón de menú
}

// Función para reiniciar el juego y volver al menú
function resetGame() {
    document.getElementById('mensaje').innerHTML = '';
    document.getElementById('menu-container').style.display = 'block'; // Mostrar el menú
    document.getElementById('contador').style.display = 'none'; // Ocultar el contador
    document.getElementById('boton-jugar').style.display = 'none'; // Ocultar el botón de detener
    document.getElementById('boton-menu').style.display = 'none'; // Ocultar el botón de menú
}
