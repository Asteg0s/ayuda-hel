$('#formRegister').on('submit', function(event) {
    event.preventDefault();

    const formData={
        fullName: $('input[name="nombre_completo"]').val(),
        documentType:$('select[name="contrasena"]').val(),
        password:$('input[name="email"]').val(),
    }

    $.post('http://localhost:4000/auth/createUser', 
        formData,
        function(data) {
            // Limpiar formulario de registro
            $('#formRegister')[0].reset();

            // Tiempo de espera para redireccionar a login.html
            setTimeout(function(){
                window.location.href = 'http://localhost:4000/login.html';
            }, 5000);

            // SweetAlert2
            Swal.fire({
              title: "Sweet!",
              text: "Modal with a custom image.",
              imageUrl: "https://brawlhalla.wiki.gg/images/thumb/400/200/Emoji_Heart_Festive_Yeti.png/800px-Emoji_Heart_Festive_Yeti.png",
              imageWidth: 400,
              imageHeight: 200,
              imageAlt: "Custom image"
            });
        }
    )
});